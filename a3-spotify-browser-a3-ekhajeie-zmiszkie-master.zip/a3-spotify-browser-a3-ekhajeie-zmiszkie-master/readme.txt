--Readme document for *Zachary Miszkiewicz, Eliya Khajeie, *zmiszkie@uci.edu, ekhajeie@uci.edu*, *zmiszkie, ekhajeie--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

20/20
- 2/2 Communicating with the webserver
- 5/5 Spotify browser home page
- 4/4 Spotify browser artist page
- 3/3 Spotify browser album page
- 3/3 Spotify browser track page
- 3/3 Spotify browser custom page


2. How long, in hours, did it take you to complete this assignment?
14 hours to both test and implement all the functions and understand how angular works. 


3. What online resources did you consult when completing this assignment? (list specific URLs)
stackoverflow, geeksforgeeks, and a lot of questions of slack


4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
Just my partner Eliya/Zac. 


5. Did you add a bonus feature to your submission? If so, what is it and how should we see it?
No, we did not get around to that.


6. Is there anything special we need to know in order to run your code?
I don't think so we tested the code with different client secrets and they are all worked. 
