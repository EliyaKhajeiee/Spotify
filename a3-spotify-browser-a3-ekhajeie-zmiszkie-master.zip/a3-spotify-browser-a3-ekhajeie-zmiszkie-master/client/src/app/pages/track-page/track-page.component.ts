import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ArtistData } from '../../data/artist-data';
import { TrackData } from '../../data/track-data';
import { AlbumData } from '../../data/album-data';
import { TrackFeature } from '../../data/track-feature';
import { CommonModule } from '@angular/common';
import { SpotifyService } from '../../services/spotify.service';
import { ThermometerComponent } from '../../components/thermometer/thermometer.component';

@Component({
  selector: 'app-track-page',
  standalone: true,
  imports: [CommonModule, ThermometerComponent],
  templateUrl: './track-page.component.html',
  styleUrl: './track-page.component.scss'
})

export class TrackPageComponent implements OnInit {
	trackId:string | undefined;
	track: TrackData | undefined;
  audioFeatures: TrackFeature[] = [];
  spotifyService: any;

  constructor(private route: ActivatedRoute, private spotify: SpotifyService) { }

  ngOnInit() {
  	this.trackId = this.route.snapshot.paramMap.get('id') || "";
    this.spotifyService = this.spotify;
    this.getTrackData();
  	//TODO: Inject the spotifyService and use it to get the track data and it's audio features
  }

  getTrackData() {
    this.spotifyService.getTrack(this.trackId).then((track: TrackData | undefined) => {
      this.track = track;
    });

    this.spotifyService.getAudioFeaturesForTrack(this.trackId).then((track: TrackFeature[]) => {
      this.audioFeatures = track;
    });
  }

  changeTime(mseconds:any){
    let seconds: string | number = Math.floor((mseconds / 1000) % 60);
    let minutes: string | number = Math.floor((mseconds / 1000 / 60) % 60);
  
    if (seconds === 0) 
    {
      seconds = '00'; 
    } else 
    {
      seconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
    }
    
    return `${minutes}:${seconds}`;
  }

  getEndpoint(type:string, id:string) {
    if (type == "track") 
    {
      return "/track/" + encodeURIComponent(id);
      
    } 
    else if (type == "album") 
    {
      return "/album/" + encodeURIComponent(id);
    } 
    else 
    {
      return "/artist/" + encodeURIComponent(id);
    }
  }

  
}
