import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { SpotifyService } from '../../services/spotify.service';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './about.component.html',
  styleUrl: './about.component.scss'
})

export class AboutComponent implements OnInit {
  name:string | undefined;
  profile_pic:string = "../../../assets/unknown.jpg";
  profile_link:string | undefined;

  //TODO: inject the Spotify service
  constructor(private spotifyService: SpotifyService) { }

  ngOnInit() {
  }
  /*
  TODO: create a function which gets the "about me" information from Spotify when the button in the view is clicked.
  In that function, update the name, profile_pic, and profile_link fields
  */

  fetchAboutMeInfo() {
    this.spotifyService.aboutMe().then(
      (data) => {
        console.log(data);
        // Assuming the response structure from Spotify API has fields 'name', 'profile_pic', and 'profile_link'
        this.name = data.name;
        this.profile_pic = data.imageURL; // Assuming Spotify returns the URL of the profile picture
        console.log(data.imageURL);
        this.profile_link = data.spotifyProfile;
      },
      (error: any) => {
        console.error('Error fetching about me information:', error);
      }
    );

  }
}