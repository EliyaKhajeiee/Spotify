import { Component, OnInit, Input, input } from '@angular/core';
import { ResourceData } from '../../data/resource-data';

import { CommonModule } from '@angular/common';
import { TrackData } from '../../data/track-data';
import { ArtistData } from '../../data/artist-data';
import { AlbumData } from '../../data/album-data';

@Component({
  selector: 'app-carousel-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './carousel-card.component.html',
  styleUrl: './carousel-card.component.scss'
})
export class CarouselCardComponent implements OnInit {
  @Input() resource:ResourceData | undefined;
  @Input() track:TrackData | undefined;
  @Input() album:AlbumData | undefined;
  @Input() artist:ArtistData | undefined;

  constructor() { }

  ngOnInit() {
  }

  getLocalUrl(): string | undefined {
    if (!this.resource) {
      return undefined;
    }
  
    // Base URL for your application
    const baseUrl = 'http://localhost:4200';
  
    // Logic to generate local URL based on resource type
    if (this.resource instanceof ArtistData) {
      return `${baseUrl}/artist/${this.resource.id}`; // URL for artists
    } else if (this.resource instanceof AlbumData) {
      return `${baseUrl}/album/${this.resource.id}`; // URL for albums
    } else if (this.resource instanceof TrackData) {
      return `${baseUrl}/track/${this.resource.id}`; // URL for tracks
    } else {
      return undefined; // Handle other resource types if needed
    }
  }

  albumInstance(val:any) {
    return (val instanceof AlbumData);
  }

  artistInstance(val:any){
    return (val instanceof ArtistData)
  }
}