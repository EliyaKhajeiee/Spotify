import { Component } from '@angular/core';
import { SpotifyService } from '../../services/spotify.service';
import { TrackData } from '../../data/track-data';
import { ArtistData } from '../../data/artist-data';
import { CarouselCardComponent } from '../carousel-card/carousel-card.component';
import { CarouselComponent } from '../carousel/carousel.component';
import { TrackListComponent } from '../track-list/track-list.component';

@Component({
  selector: 'app-top-user-tracks',
  standalone: true,
  imports: [CarouselComponent, CarouselCardComponent, TrackListComponent],
  templateUrl: './top-user-tracks.component.html',
  styleUrl: './top-user-tracks.component.scss'
})

export class TopUserTracksComponent {
	topArtists:ArtistData[] | undefined;
	topTracks:TrackData[] | undefined;
  spotifyService: any;
  name:string | undefined;
  profile_pic:string = "../../../assets/unknown.jpg";
  profile_link:string | undefined;

  constructor(private spotify:SpotifyService) { }

  ngOnInit() {
    this.spotifyService = this.spotify;
    this.fetchAboutMeInfo();
    this.getData();
    //TODO: Inject the spotifyService and use it to get the artist data, related artists, top tracks for the artist, and the artist's albums

  }
  getData() 
  {
    // Fetch artist data
    
    this.spotifyService.meTopArtists().then((artist: ArtistData[] | undefined) => {
      this.topArtists = artist;
      console.log(this.topArtists);
    });
    
    this.spotifyService.meTopTracks().then((track: TrackData[] | undefined) => {
      this.topTracks = track;
      console.log(this.topTracks);
    });
    
  }

  fetchAboutMeInfo() {
    this.spotifyService.aboutMe().then(
      (data:any) => {
        console.log(data);
        // Assuming the response structure from Spotify API has fields 'name', 'profile_pic', and 'profile_link'
        this.name = data.name;
        this.profile_pic = data.imageURL; // Assuming Spotify returns the URL of the profile picture
        console.log(data.imageURL);
        this.profile_link = data.spotifyProfile;
      },
      (error: any) => {
        console.error('Error fetching about me information:', error);
      }
    );

  }
}


//We use this to get the endpoint for the data 
/*router.get('/me/top/tracks', function(req, res, next) {
	makeAPIRequest('https://api.spotify.com/v1/me/top/tracks', res);
});*/