import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopUserTracksComponent } from './top-user-tracks.component';

describe('TopUserTracksComponent', () => {
  let component: TopUserTracksComponent;
  let fixture: ComponentFixture<TopUserTracksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TopUserTracksComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TopUserTracksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
