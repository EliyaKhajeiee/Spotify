export abstract class ResourceData {
  static map(arg0: (item: any) => import("./artist-data").ArtistData): any {
    throw new Error('Method not implemented.');
  }
	category:string = "unknown";
	name:string;
	imageURL:string;
	id:string;
	url:string | undefined;

	constructor(objectModel:any) {
		this.name = objectModel['name'];
		this.id = objectModel['id'];
		if(objectModel['images'] && objectModel['images'].length > 0) {
			this.imageURL = objectModel['images'][0].url;
		} else if(objectModel['album'] && objectModel['album']['images'] && objectModel['album']['images'].length > 0) {
			this.imageURL = objectModel['album']['images'][0].url;
		} else {
			this.imageURL = '../../assets/unknown.jpg';
		}

		if('spotify' in objectModel['external_urls']) {
			this.url = objectModel['external_urls']['spotify'];
		}
	}
}
